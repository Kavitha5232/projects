package com.demo.example;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PlacementMgmtApplicationTests {

	@Test
	void contextLoads() {
	}

}
