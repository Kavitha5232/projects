package com.demo.example.service;

import java.util.List;

import com.demo.example.entity.College;

public interface CollegeService {

	public College saveCollege(College college);

	public List<College> fetchCollegeList();

	public College fetchCollegeById(Long collegeId);

	public void deleteCollegeById(Long collegeId);

	public College updateCollege(Long collegeId, College college);



	

	

}
