package com.demo.example.service;

import java.util.List;
import java.util.Objects;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.demo.example.entity.College;
import com.demo.example.repository.CollegeRepository;

@Service
public class CollegeServiceImpl implements CollegeService {
@Autowired
private CollegeRepository collegeRepository;

	@Override
	public College saveCollege(College college) {
		
		return collegeRepository.save(college);
	}

	@Override
	public List<College> fetchCollegeList() {
		
		return collegeRepository.findAll();
		
	}

	@Override
	public College fetchCollegeById(Long collegeId) {
	
		return collegeRepository.findById(collegeId).get();
		
	}

	@Override
	public void deleteCollegeById(Long collegeId) {
		collegeRepository.deleteById(collegeId);
		
	}

	@Override
	public College updateCollege(Long collegeId, College college) {
		
		College colDB = collegeRepository.findById(collegeId).get();
		
		 if(Objects.nonNull(college.getCollegeName()) &&
			       !"".equalsIgnoreCase(college.getCollegeName())) {
			           colDB.setCollegeName(college.getCollegeName());
			       }

			       if(Objects.nonNull(college.getCollegeLocation()) &&
			               !"".equalsIgnoreCase(college.getCollegeLocation())) {
			           colDB.setCollegeLocation(college.getCollegeLocation());
			       }

			      return collegeRepository.save(colDB);
			      
		
		
	}
}
