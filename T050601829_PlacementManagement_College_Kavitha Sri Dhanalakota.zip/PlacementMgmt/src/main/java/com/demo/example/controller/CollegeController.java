package com.demo.example.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;


import com.demo.example.entity.College;
import com.demo.example.service.CollegeService;

@RestController
public class CollegeController {
	
	@Autowired
	private CollegeService collegeService;
	
	 @PostMapping("/colleges")
	    public College saveCollege(@RequestBody College college) {
	       
	        return collegeService.saveCollege(college);
	    }
	 
	 @GetMapping("/colleges")
	    public List<College> fetchCollegeList() {
	        //LOGGER.info("Inside fetchCollegeList of CollegeController");
	        return collegeService.fetchCollegeList();
	    }
	 
	 @GetMapping("/colleges/{id}")
	    public College fetchCollegeById(@PathVariable("id") Long collegeId)
	            {
	        return collegeService.fetchCollegeById(collegeId);
	    }
	 
	 @DeleteMapping("/colleges/{id}")
	    public String deleteCollegeById(@PathVariable("id") Long collegeId) {
	        collegeService.deleteCollegeById(collegeId);
	        return "College deleted Successfully!!";
	    }
	 
	 @PutMapping("/colleges/{id}")
	    public College updateCollege(@PathVariable("id") Long collegeId,
	                                       @RequestBody College college) {
	        return collegeService.updateCollege(collegeId,college);
	    }
	 
}
	
	
	


