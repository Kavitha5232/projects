package com.demo.example.entity;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;

@Entity
public class College {

	@Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Long collegeId;
	 private String collegeName;
	    private String collegeLocation;
		public Long getCollegeId() {
			return collegeId;
		}
		public void setCollegeId(Long collegeId) {
			this.collegeId = collegeId;
		}
		public String getCollegeName() {
			return collegeName;
		}
		public void setCollegeName(String collegeName) {
			this.collegeName = collegeName;
		}
		public String getCollegeLocation() {
			return collegeLocation;
		}
		public void setCollegeLocation(String collegeLocation) {
			this.collegeLocation = collegeLocation;
		}
		public College() {
			super();
		}
		public College(Long collegeId, String collegeName, String collegeLocation) {
			super();
			this.collegeId = collegeId;
			this.collegeName = collegeName;
			this.collegeLocation = collegeLocation;
		}
		@Override
		public String toString() {
			return "College [collegeId=" + collegeId + ", collegeName=" + collegeName + ", collegeLocation="
					+ collegeLocation + ", getCollegeId()=" + getCollegeId() + ", getCollegeName()=" + getCollegeName()
					+ ", getCollegeLocation()=" + getCollegeLocation() + ", getClass()=" + getClass() + ", hashCode()="
					+ hashCode() + ", toString()=" + super.toString() + "]";
		}
	    
}
